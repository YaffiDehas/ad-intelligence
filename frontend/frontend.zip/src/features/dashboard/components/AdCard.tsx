import { useState } from 'react';
import type { Ad } from '../../../types/api';

interface AdCardProps {
  ad: Ad;
}

export function AdCard({ ad }: AdCardProps) {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="ad-card">
      <div className="ad-card__image-wrap">
        {imgError ? (
          <div className="ad-card__image-fallback">🖼️</div>
        ) : (
          <img
            className="ad-card__image"
            src={ad.imageUrl}
            alt={ad.title}
            loading="lazy"
            onError={() => setImgError(true)}
          />
        )}
      </div>

      <div className="ad-card__body">
        <div className="ad-card__title">{ad.title}</div>
        <div className="ad-card__desc">{ad.description}</div>
        <div className="ad-card__footer">
          <span className="ad-card__duplication">
            ⧉ {ad.duplications}
          </span>
          <span className="ad-card__launched">{ad.launched}</span>
        </div>
      </div>
    </div>
  );
}
