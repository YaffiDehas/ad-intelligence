import { lazy, Suspense } from 'react';
import { useAppStore } from '../../../store/useAppStore';
import { useStats } from '../../../hooks/useDataFetching';
import { KPICard } from './KPICard';

const QuickWins = lazy(() =>
  import('./QuickWins').then((m) => ({ default: m.QuickWins }))
);

const KPI_CONFIG = [
  { section: 'active' as const, label: 'Active Ads', icon: '📡', colorVar: '--kpi-1' },
  { section: 'launched' as const, label: 'Ads Launched', icon: '🚀', colorVar: '--kpi-2' },
  { section: 'hooks' as const, label: 'New Hooks', icon: '🎣', colorVar: '--kpi-3' },
  { section: 'lifespan' as const, label: 'Creative Lifespan', icon: '⏳', colorVar: '--kpi-4' },
];

function KPISection() {
  const { selectedProduct, startDate, endDate } = useAppStore();

  const results = KPI_CONFIG.map(({ section }) =>
    // eslint-disable-next-line react-hooks/rules-of-hooks
    useStats(section, selectedProduct, startDate, endDate)
  );

  return (
    <div>
      <p className="section-title">Key Metrics</p>
      <div className="kpi-grid">
        {KPI_CONFIG.map(({ section, label, icon, colorVar }, i) => (
          <KPICard
            key={section}
            label={label}
            icon={icon}
            color={`var(${colorVar})`}
            data={results[i].data}
            isLoading={results[i].isLoading}
            animDelay={i * 0.05}
          />
        ))}
      </div>
    </div>
  );
}

export function Dashboard() {
  const { selectedProduct } = useAppStore();

  return (
    <main className="main-content">
      {!selectedProduct && (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-muted)', padding: '4px 0' }}>
          ← Select a product from the sidebar to load metrics
        </div>
      )}
      <KPISection />
      <Suspense
        fallback={
          <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}>
            <div className="spinner" />
          </div>
        }
      >
        <QuickWins />
      </Suspense>
    </main>
  );
}
