import { useAppStore } from '../../../store/useAppStore';
import { useServerState } from '../../../hooks/useDataFetching';

export function Header() {
  const { startDate, endDate, theme, setDateRange, toggleTheme } = useAppStore();
  const { data: serverState } = useServerState();

  const formattedTime = serverState?.timestamp
    ? new Date(serverState.timestamp).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })
    : '—';

  return (
    <header className="header">
      <div className="header__logo">
        <div className="header__logo-icon">AI</div>
        <span className="header__logo-text">Ad Intelligence</span>
      </div>

      <div className="header__controls">
        <div className="date-range">
          <label>From</label>
          <input
            type="date"
            value={startDate}
            max={endDate}
            onChange={(e) => setDateRange(e.target.value, endDate)}
          />
          <span className="date-range__sep">→</span>
          <input
            type="date"
            value={endDate}
            min={startDate}
            onChange={(e) => setDateRange(startDate, e.target.value)}
          />
        </div>
      </div>

      <div className="header__spacer" />

      <div className="header__right">
        <div className="server-badge">
          <span
            className={`server-badge__dot${
              serverState?.status === 'up' ? '' : ' server-badge__dot--down'
            }`}
          />
          {serverState ? `Updated ${formattedTime}` : 'Connecting...'}
        </div>

        <button
          className="theme-toggle"
          onClick={toggleTheme}
          title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
        >
          {theme === 'dark' ? '☀️' : '🌙'}
        </button>
      </div>
    </header>
  );
}
