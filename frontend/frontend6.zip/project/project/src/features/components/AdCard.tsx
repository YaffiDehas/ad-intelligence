import { useState, useCallback } from 'react';
import type { Ad } from '../../types/api';
import { normalizeImageUrl } from '../../api/endpoints';

type ImageStatus = 'loading' | 'loaded' | 'error';

interface AdCardProps {
  ad: Ad;
}

function getInitials(title: string): string {
  return title
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');
}

export function AdCard({ ad }: AdCardProps) {
  const [status, setStatus] = useState<ImageStatus>('loading');
  const [retried, setRetried] = useState(false);

  const stableImageUrl = normalizeImageUrl(ad.imageUrl);

  const handleError = useCallback(() => {
    if (!retried) {
      setRetried(true);
      const img = new Image();
      img.src = `${stableImageUrl}&retry=1`;
      img.onload = () => setStatus('loaded');
      img.onerror = () => setStatus('error');
    } else {
      setStatus('error');
    }
  }, [retried, stableImageUrl]);

  return (
    <div className="ad-card">
      <div className="ad-card__image-wrap">

        {/* Skeleton — visible only while loading */}
        {status === 'loading' && (
          <div className="ad-card__skeleton" aria-hidden="true" />
        )}

        {/* Designed fallback — visible only on error */}
        {status === 'error' && (
          <div className="ad-card__fallback" aria-label="Image unavailable">
            <span className="ad-card__fallback-initials">
              {getInitials(ad.title)}
            </span>
          </div>
        )}

        {/* Image — only mounted when not errored, fades in on load */}
        {status !== 'error' && (
          <img
            className="ad-card__image"
            src={stableImageUrl}
            alt={ad.title}
            loading="lazy"
            style={{ opacity: status === 'loaded' ? 1 : 0 }}
            onLoad={() => setStatus('loaded')}
            onError={handleError}
          />
        )}

      </div>

      <div className="ad-card__body">
        <div className="ad-card__title">{ad.title}</div>
        <div className="ad-card__desc">{ad.description}</div>
        <div className="ad-card__footer">
          <span className="ad-card__duplication">⧉ {ad.duplications}</span>
          <span className="ad-card__launched">{ad.launched}</span>
        </div>
      </div>
    </div>
  );
}