import type { ApiConfig } from '../types/api';

let configCache: ApiConfig | null = null;

export async function loadConfig(): Promise<ApiConfig> {
  if (configCache) return configCache;
  const res = await fetch('/config.json');
  configCache = await res.json();
  return configCache!;
}

export async function apiGet<T>(path: string, params?: Record<string, string>): Promise<T> {
  const config = await loadConfig();
  const url = new URL(`${config.api.baseUrl}${path}`);
  if (params) {
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  }
  const res = await fetch(url.toString(), {
    signal: AbortSignal.timeout(config.api.timeout),
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}
