import { apiGet } from './client';
import type {
  ServerState,
  ProductsResponse,
  StatsResponse,
  WinsResponse,
  StatSection,
} from '../types/api';

export const fetchServerState = (): Promise<ServerState> =>
  apiGet<ServerState>('/api/server-state');

export const fetchProducts = (): Promise<ProductsResponse> =>
  apiGet<ProductsResponse>('/api/products');

export const fetchStats = (
  section: StatSection,
  product: string,
  start: string,
  end: string
): Promise<StatsResponse> =>
  apiGet<StatsResponse>(`/api/stats/${section}`, { product, start, end });

export const fetchWins = (
  page: number,
  product: string,
  start: string,
  end: string
): Promise<WinsResponse> =>
  apiGet<WinsResponse>('/api/wins', {
    page: String(page),
    product,
    start,
    end,
  });
  
  export function normalizeImageUrl(url: string): string {
    try {
      const parsed = new URL(url);
      parsed.searchParams.delete('t');
      return parsed.toString();
    } catch {
      return url;
    }
  }
