import { lazy, Suspense } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { useStats } from '../../hooks/useDataFetching';
import { KPICard } from '../KPICard/KPICard';
import type { StatSection } from '../../types/api';

const QuickWins = lazy(() =>
  import('../QuickWins/QuickWins').then((m) => ({ default: m.QuickWins }))
);

const KPI_CONFIG: {
  section: StatSection;
  label: string;
  icon: string;
  colorVar: string;
}[] = [
  { section: 'active',   label: 'Active Ads',       icon: '📡', colorVar: '--kpi-1' },
  { section: 'launched', label: 'Ads Launched',      icon: '🚀', colorVar: '--kpi-2' },
  { section: 'hooks',    label: 'New Hooks',         icon: '🎣', colorVar: '--kpi-3' },
  { section: 'lifespan', label: 'Creative Lifespan', icon: '⏳', colorVar: '--kpi-4' },
];

interface KPIItemProps {
  section: StatSection;
  label: string;
  icon: string;
  colorVar: string;
  index: number;
}

function KPIItem({ section, label, icon, colorVar, index }: KPIItemProps) {
  const { selectedProduct, startDate, endDate } = useAppStore();
  const { data, isLoading } = useStats(section, selectedProduct, startDate, endDate);

  return (
    <KPICard
      label={label}
      icon={icon}
      color={`var(${colorVar})`}
      data={data}
      isLoading={isLoading}
      animDelay={index * 0.05}
    />
  );
}

function KPISection() {
  return (
    <div>
      <p className="section-title">Key Metrics</p>
      <div className="kpi-grid">
        {KPI_CONFIG.map((config, i) => (
          <KPIItem key={config.section} {...config} index={i} />
        ))}
      </div>
    </div>
  );
}

export function Dashboard() {
  const { selectedProduct } = useAppStore();

  return (
    <main className="main-content">
      {!selectedProduct && (
        <div
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: 12,
            color: 'var(--text-muted)',
            padding: '4px 0',
          }}
        >
          ← Select a product from the sidebar to load metrics
        </div>
      )}
      <KPISection />
      <Suspense
        fallback={
          <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}>
            <div className="spinner" />
          </div>
        }
      >
        <QuickWins />
      </Suspense>
    </main>
  );
}