import { useAppStore } from '../../store/useAppStore';
import { useProducts } from '../../hooks/useDataFetching';

const PRODUCT_ICONS: Record<string, string> = {
  'Nike Air Max': '👟',
  'Nike React': '⚡',
  'Nike Pegasus': '🪶',
  'Nike Mercurial': '🔥',
  'Nike Blazer': '🌟',
};

export function Sidebar() {
  const { selectedProduct, setProduct } = useAppStore();
  const { data, isLoading } = useProducts();

  return (
    <aside className="sidebar">
      <span className="sidebar__label">Products</span>

      {isLoading &&
        Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="sidebar__skeleton" />
        ))}

      {data?.products.map((product) => (
        <button
          key={product}
          className={`sidebar__item${
            selectedProduct === product ? ' sidebar__item--active' : ''
          }`}
          onClick={() => setProduct(product)}
        >
          <span className="sidebar__item-icon">
            {PRODUCT_ICONS[product] ?? '📦'}
          </span>
          <span className="sidebar__item-name">{product}</span>
        </button>
      ))}
    </aside>
  );
}
