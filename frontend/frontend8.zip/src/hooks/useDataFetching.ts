import { useQuery, useInfiniteQuery } from '@tanstack/react-query';
import { fetchServerState, fetchProducts, fetchStats, fetchWins } from '../api/endpoints';
import type { StatSection } from '../types/api';

export const useServerState = () =>
  useQuery({
    queryKey: ['server-state'],
    queryFn: fetchServerState,
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

export const useProducts = () =>
  useQuery({
    queryKey: ['products'],
    queryFn: fetchProducts,
    staleTime: Infinity,
  });

export const useStats = (
  section: StatSection,
  product: string,
  start: string,
  end: string
) =>
  useQuery({
    queryKey: ['stats', section, product, start, end],
    queryFn: () => fetchStats(section, product, start, end),
    enabled: !!product,
    staleTime: 30_000,
  });

export const useWins = (product: string, start: string, end: string) =>
  useInfiniteQuery({
    queryKey: ['wins', product, start, end],
    queryFn: ({ pageParam }) => fetchWins(pageParam as number, product, start, end),
    initialPageParam: 1,
    getNextPageParam: (lastPage, _allPages, lastPageParam) =>
      lastPage.has_more ? (lastPageParam as number) + 1 : undefined,
    enabled: !!product,
    staleTime: 30_000,
  });
