export interface ServerState {
  status: 'up' | 'down';
  timestamp: string;
  uptime: number;
}

export interface ProductsResponse {
  products: string[];
}

export interface StatsResponse {
  section: string;
  current: number;
  trend: number;
  benchmark: number;
}

export interface Ad {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  launched: string;
  duplications: number;
}

export interface WinsResponse {
  ads: Ad[];
  has_more: boolean;
}

export type StatSection = 'active' | 'launched' | 'hooks' | 'lifespan';

export interface ApiConfig {
  api: {
    baseUrl: string;
    timeout: number;
    endpoints: {
      serverState: string;
      products: string;
      stats: string;
      wins: string;
    };
  };
  mockSettings: {
    enableLatency: boolean;
    latencyRange: [number, number];
  };
}
